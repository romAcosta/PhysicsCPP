#pragma once
#include "world.h"

void ApplyGravitation(bodies_t& bodies, float strength);
